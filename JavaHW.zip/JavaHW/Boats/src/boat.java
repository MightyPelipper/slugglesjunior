//this is the boat class used in the test file
//Samir Mahamed
public class boat {

	private String licPlate;
	private int mileage;
	private double cost;
	private int speed;
	
	// constructors
	public boat()
	{
		licPlate = "";
		mileage = 0;
		cost = 0.0;
	}
	public boat (String l, int m , double c)
	{
		licPlate = l;
		mileage = m;
		cost = c;
		
	}
	public boat (String l, int m, double c, int s)
	{
		licPlate = l;
		mileage = m;
		cost = c;
		speed = s;

	}
	public void speedUp(int s)	{
		speed = speed+s;
	}
	//checks if the boat is speeding 
	public boolean areYouObeyingTheLaw (int spLimit)	{
		if (speed > spLimit)
			return false; //false if it is not speeding
		else
			return true; //true if speeding
	}
	
	//getters 
	public String getLicPlate()
	{
		return licPlate; //license plate of the boat
	}
	
	public int getMileage()
	{
		return mileage; //milage of the boat
	}
	
	public double getCost()
	{
		return cost; //cost of the boats
	}
	
	//Setters
	public void setLicPlate(String l)
	{
		licPlate = new String(l); //sets a licence plate
	}
	
	public void setCost( double c)
	{
		cost = c; //sets a cost
	}
	
	public void setMileage(int m)
	{
		mileage = m; //sets mileage
	}
	
	//methods
	//turn in to string using the info given in test file
	public String toString()
	{
		return ("The licence plate number is " + licPlate +" , and Has a mileage of  "+ mileage +" and costs $" + cost);
	}
	
	//check if the boats are the same
	public boolean equals(boat b2)
	{
		if (this.licPlate.equals(b2.licPlate))
			return true;
		else
			return false;
	}
	
	//make the milage go up with speed and time
	
	public void sail(double sailTime, int speed)
	{
		double todaysMileage;	//total miles traveled	
									
		
		todaysMileage = sailTime * speed;
		mileage = mileage + (int) todaysMileage;
	}
	
	
	
	
	
}
