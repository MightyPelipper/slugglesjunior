//This program was made by Samir Mahamed
//This program creates 3 boats and checks if their the same. It also can change the value of the milage and can check for speeding
public class boatTest
{
	public static void main (String args[])
		{
			boat KawasakiX9 = new boat("RFX101" , 6400, 12000 ); // new boat object
			boat HondaR4 = new boat("TOK880" , 10000, 9000); //new boat object
			
			System.out.println("KawasakiX9 Sun Cruizer: " + KawasakiX9 ); //throw into toString
			System.out.println("HondaR4 Tide Ripper: " + HondaR4 ); //throw into toString
			
		
			//setup a new boat
			boat SuzukiM2 = new boat();
			SuzukiM2.setLicPlate("BIG888");
			SuzukiM2.setMileage(400);
			SuzukiM2.setCost(50000);
			//now print out all that junk
			System.out.println("Suzuki HyperNautica: " + SuzukiM2 ); //throw into toString
			
			if (KawasakiX9.equals(HondaR4))
				System.out.println("These boats are the same.");
			else{
				System.out.println("These boats are not the same.");
			}
			
			//This changes the boat mileage
			//set a speed and a sail time
			KawasakiX9.sail(2.0 , 60);
			System.out.println("KawasakiX9 is now going on a trip");
			
			//print out the updated mileage
			System.out.println("KawasakiX9: " + KawasakiX9);
			
			//now check for speeding
			System.out.println("Now passing a speed monitor speed limit is 65\n");
			KawasakiX9.speedUp(80); //speed up the boat
			
			//check if boat is going faster than the speed limit
			if (KawasakiX9.areYouObeyingTheLaw(65))
				System.out.println("That is an acceptable speed.");
			else
				System.out.println("Too Fast Slow Down.");
			
			
			
		}
		
	}
	
	

