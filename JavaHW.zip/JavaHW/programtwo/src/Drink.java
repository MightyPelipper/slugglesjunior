// Samir Mahamed 
//This program gets a name of a drink it sugar content and how much it costs and compares to if they are the same drink.
public class Drink {
	
	private String name;
	private int sugarContent;
	private double cost;
	
	// constructors
	public Drink()
	{
		name = "";
		sugarContent = 0;
		cost = 0.0;
	}
	public Drink (String n, int s , double c)
	{
		name = n;
		sugarContent = s;
		cost = c;
		
	}
	
	//getters 
	public String getName()
	{
		return name;
	}
	
	public int getSugarContent()
	{
		return sugarContent;
	}
	
	public double getCost()
	{
		return cost;
	}
	
	//Setters
	public void setName(String n)
	{
		name = n;
	}
	
	public void setCost( double c)
	{
		cost = c;
	}
	
	public void setSugarContent(int s)
	{
		sugarContent = s;
	}
	
	//turn in to string
	public String toString()
	{
		return ("The Drink " + name +" Has "+ sugarContent +" grams of sugar and costs $" + cost);
	}
	
	//check if the drinks are the same
	public boolean equals(Drink d2)
	{
		if (this.name.equals(d2.name))
			return true;
		else
			return false;
	}
	
	//Check if drink has more than daily sugar content
	public void sugar(int s ) 
	{
		int dailySugar; 
		int sugarDifference;
		
		dailySugar = 24;
		sugarDifference = dailySugar - s;
		
		
	}
	//how much a gram of sugar costs
	public void gram(int s, double c) 
	{
		double gramPrice;
		gramPrice = c / s; 
		
		
	}
	
	
	
	
	
}
