//Samir Mahamed
//This program asks users to enter a zipcode and returns information about the zipcode and fun facts.
import java.util.Scanner;
public class program2 {
	public static void main(String args[])
	{
		//create a input scanner
		//Scanner scan = new Scanner(System.in);
		//declare some variables
		int zipcode;
		
		char answer; 
		answer = 'y';
		System.out.println("This program was written by Samir Mahamed"); //name plug
		while ( answer == 'y'|| answer == 'Y') //checks if user wants to try again
		{
			//print out some information for the user to choose from
			System.out.println("Available Zipcodes to choose from:\n");
			System.out.println("55347 , 55001, 55002, 55003, 55004, 55005, 55006\n");
			System.out.println("Please enter a zipcode to learn more about that area.\n");
			//get the input for zipCode
			Scanner scan = new Scanner(System.in); //creates a scanner
			zipcode = scan.nextInt();
			String numberAsString = Integer.toString(zipcode); //turn zipcode into a string
			int length = numberAsString.length(); //gets the length of zipcode in its string form
	
			//check if zipcode is greater than 0 and has a length of 5
			if ( zipcode > 0 && length == 5 ){ 
				//pull some info with the corresponding zipcode
				if(zipcode == 55347){
					System.out.println("Eden Prairie, MN 55417\n");
					System.out.println("Eden Prairie is in Hennepin County.\n");
					System.out.println("Eden Prairie hosts a yearly Air Expo every year at Flying Cloud Regional Airport.\n");
				}
				if(zipcode == 55001){
					System.out.println("Afton, MN 55001.\n");
					System.out.println("Afton is in Washington County.\n");
					System.out.println("Afton is well known for Afton Alps, the largest ski and snowboard area in the Twin Cities metropolitan area.\n");
				}
				if(zipcode == 55002){
					System.out.println("Almelund, MN 55002\n");
					System.out.println("Almelund is in Chisago County.\n");
					System.out.println("The first European visitors to the area were French traders, who bought furs from the resident Ojibwa Indians in the 17th century");
				}
				if(zipcode == 55003){
					System.out.println("Bayport, MN 55003\n");
					System.out.println("Bayport is in Washington County\n");
					System.out.println("the early economy of Bayport centered around the lumber industry");
				}
				if(zipcode == 55005){
					System.out.println("Bethel, MN 55005\n");
					System.out.println("Bethel is in Anoka County\n");
					System.out.println("Bethel was incorporated as a village in 1902");
					
				}
				if(zipcode == 55006){
					System.out.println("Braham, MN 55006\n");
					System.out.println("Braham is in Isanti County\n");
					System.out.println("A post office called Braham has been in operation since 1891");
					
				}
				if(zipcode == 55007){
					System.out.println("Brook Park, MN 55007\n");
					System.out.println("Pine County\n");
					System.out.println("he city has a total area of 1.01 square miles\n");
					
				}
				
				
			}
				//tell the user what they got wrong
			
			else if (zipcode != 55001||zipcode!=55347||zipcode!=55002||zipcode!=55003||zipcode!=55005||zipcode!=55006||zipcode!=55007){
				System.out.println("that is not one of the zipcodes I gave you.\n");
				
			}
			
			if (length > 5){
				System.out.println("That zipcode has too long, it needs to have 5 numbers try again\n");
			}
			
			if (length < 5){
				System.out.println("That zipcode is too short it needs to have 5 numbers try again\n");
			}
			if (zipcode < 0){
				System.out.println("negetive zipcodes dont exsist try again\n");
			}
			
		System.out.println("Would you like to try again? (Y/N) \n");
		answer = scan.next(".").charAt(0);
		
		}
		//ends the program if user enters any thing that is 
		while ( answer == 'N' || answer == 'n'||answer != 'y'||answer!='Y'){
			System.out.println("Good Bye!\n");
		break;
		}
		
	}
}
// some test cases:
// If you enter a unknown zipcode it will ask you to try again
// if you enter y it will continue the loop
//if you enter n it will end the program
//zipcode is turned to a string and its length is checked to see if it is a zipcode or not
//zipcode is tested to see if its a negetive number and you will be asked to try again.
//if you enter any other key that is not Y , y , n , N it will read it as if you want to quit
//********************************************************
//test cases

//input          output

//y              please enter a zipcode

//5550001        that is not one of the zipcodes i gave you. that zipcode has too many numbers try again.

//x-55347         negitive zipcodes dont exsist try again












