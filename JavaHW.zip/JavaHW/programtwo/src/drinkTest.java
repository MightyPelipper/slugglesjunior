//tests drink.java 
//Samir Mahamed
public class drinkTest {
	public static void main (String args[])
	{
		Drink pop = new Drink("Coca-Cola" , 64, 1.89 ); // new pop object
		Drink water = new Drink("Dasani" , 0, 1.69); //new water object
		
		System.out.println("Coca-Cola: " + pop ); //throw into toString
		System.out.println("Dasani: " + water ); //throw into toString
		
		if (pop.equals(water))
			System.out.println("These drinks are the same.");
		else{
			System.out.println("These drinks are not the same.");
		}
			
		pop.gram(64,1.89);
		
		//double gramPrice = pop.getCost()/pop.getSugarContent();
		
		//System.out.println("Every gram of sugar in a coke costs $" + gramPrice);
		
		
		
		
	}
	
}
