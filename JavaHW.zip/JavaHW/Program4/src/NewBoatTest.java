//Samir Mahamed
//This program creates a boat and then stores the boat into a Dock. The user enters the name of the boat to pull its info out of the dock.
import java.util.Scanner;
public class NewBoatTest {
	public static void main (String args[])
	{
		
		Scanner scan = new Scanner (System.in);
		String firstBoat;
		boatDock lakePort = new boatDock(); //boatdock
		char keepGoing = 'Y';
		
		lakePort.add("Kawasaki" , 6400, 12000);
		lakePort.add("HondaR4", 6867, 5022);
		lakePort.add("Suszuki" , 888, 15000);
		lakePort.add("Yamaha", 4868, 5001);
		lakePort.add("Titan" , 457784, 69000);
		lakePort.add("Mayton", 100100, 50000);
		lakePort.add("Titanic" , 6404, 1112000);
		lakePort.add("Ridgeline", 59898, 52000);
		lakePort.add("Cat" , 6400, 23000);
		lakePort.add("Longway", 5487, 5000);
		
		//ten different boats
		
		
		while (keepGoing == 'Y'|| keepGoing == 'y' )
		{
		System.out.println("Boat Names In Dock:\n");	
		System.out.println("Kawasaki, HondaR4, Susuzuki,Yamaha,Titan,Mayton.Titanic,Ridgeline,Cat,Longway\n");
		System.out.println("Please Enter The name of the boat.\n");
		
		
		firstBoat = scan.nextLine(); 
		if( lakePort.findBoat(firstBoat) == null){
			System.out.println("That is not one of the boats in the dock");
		}
		else{
		System.out.println (lakePort.findBoat(firstBoat));
		}
		System.out.println("Would you like to continue? (Y/N)");
		keepGoing = scan.next().charAt(0);
		scan.nextLine();
		}
		
		if (keepGoing != 'Y'|| keepGoing != 'y')
		{
			System.out.println("Ending program");
		}
	}
	
}
