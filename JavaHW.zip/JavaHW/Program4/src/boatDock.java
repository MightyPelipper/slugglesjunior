//This will store all boats into a new dock
public class boatDock {
	private boat boatlot[];
	private int numBoats;
	
	public boatDock()
	{
		boatlot = new boat[200];
		numBoats = 0;
	}
	
	public void add(String l, int m, double c)
	{
		boatlot[numBoats++] = new boat (l, m, c);
		// ADD A CAR TO THE CARLOT
	}
	
	public boat findBoat(String l)
	{
		for ( int i=0; i < numBoats; i++ )
		{
			if ( boatlot[i] != null && boatlot[ i ].getLicPlate().equals( l ) )
				return boatlot[ i ];
		}
		return null;
		
		
	
	}
	
	public String toString()
	{
		String results = "";
		for (int i=0; i < numBoats; i++)
			results += boatlot[i].toString() + "\n";
		
		return results;
	}

}
