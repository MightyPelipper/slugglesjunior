//Program Created By Samir Mahamed
//This program asks the user for a zipcode and returns information about the location
import java.util.Scanner;
public class programtwo {
	public static void main(String args[])
	{
		//create a input scanner
		Scanner scan = new Scanner(System.in);
		//declare some variables
		String zipcode;
		String answer = "y";
		
		while ( answer == "y")
		{
			//print out some information for the user to choose from
			System.out.println("Available Zipcodes to choose from:\n");
			System.out.println("55347 , 55001, 55002, 55003, 55004, 55005, 55006\n");
			System.out.println("Please enter a zipcode to learn more about that area.\n");
			//get the input for zipCode
			zipcode = scan.nextLine();
			//pull some info with the corresponding zipcode
			if(zipcode == "55347"){
				System.out.println("Enter info for Eden Prairie");
			}
			if(zipcode == "55001"){
				System.out.println("Enter info for Afton");
			}
			if(zipcode == "55002"){
				System.out.println("Enter info for Almelund");
			}
			if(zipcode == "55003"){
				System.out.println("Enter info for Bayport");
			}
			if(zipcode == "55005"){
				System.out.println("Enter info for Bethel");
			}
			if(zipcode == "55006"){
				System.out.println("Enter info for Braham");
			}
			if(zipcode == "55007"){
				System.out.println("Enter info for Brook Park");
			}
			else{
				System.out.println("Thats not a Zipcode");
			}
			//ask the user if they want to continue
			System.out.println("Would you like to continue?\n");
			answer = scan.nextLine();
		}
		
		
		
	}
}
